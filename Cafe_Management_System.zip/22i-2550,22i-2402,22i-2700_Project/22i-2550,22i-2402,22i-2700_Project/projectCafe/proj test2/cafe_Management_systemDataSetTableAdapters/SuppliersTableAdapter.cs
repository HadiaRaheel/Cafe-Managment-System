﻿namespace cafe_Management_systemDataSetTableAdapters
{
    internal class SuppliersTableAdapter
    {
    }
}