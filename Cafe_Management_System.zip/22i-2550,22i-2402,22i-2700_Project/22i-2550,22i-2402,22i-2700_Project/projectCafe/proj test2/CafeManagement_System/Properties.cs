﻿namespace CafeManagement_System
{
    internal class Properties
    {
    }
}