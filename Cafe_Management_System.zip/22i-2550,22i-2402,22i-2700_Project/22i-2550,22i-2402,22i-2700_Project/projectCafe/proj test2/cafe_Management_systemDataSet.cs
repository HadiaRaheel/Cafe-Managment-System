﻿namespace CMS.UI_Forms.Employee
{
    internal class cafe_Management_systemDataSet
    {
    }
}